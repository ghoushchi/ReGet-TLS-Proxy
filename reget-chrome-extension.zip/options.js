const api = globalThis.browser ?? globalThis.chrome;

const DEFAULTS = {
  confirm: true,
  sendCookies: true,
  sendReferrer: true,
  takeOverDownloads: false,
};

const FIELDS = Object.keys(DEFAULTS);

async function load() {
  const cfg = { ...DEFAULTS, ...(await api.storage.local.get(DEFAULTS)) };
  for (const key of FIELDS) document.getElementById(key).checked = Boolean(cfg[key]);
}

function save() {
  const patch = {};
  for (const key of FIELDS) patch[key] = document.getElementById(key).checked;
  api.storage.local.set(patch);
}

function show(text, ok) {
  const el = document.getElementById("status");
  el.textContent = text;
  el.className = ok ? "ok" : "err";
  el.style.display = "block";
}

for (const key of FIELDS) {
  document.getElementById(key).addEventListener("change", save);
}

document.getElementById("test").addEventListener("click", async () => {
  show("Contacting native host...", true);
  try {
    const reply = await api.runtime.sendNativeMessage("com.reget.deluxe", { action: "ping" });
    if (reply?.ok) {
      show(
        `Connected.\nHost version: ${reply.version}\nReGetDx: ${reply.regetPath || "not located"}\n` +
          `Transport: ${reply.transport}`,
        true
      );
    } else {
      show(`Host replied with an error:\n${reply?.error || "unknown"}`, false);
    }
  } catch (err) {
    show(
      `Could not reach the native host.\n\n${err?.message || err}\n\n` +
        `Run tools\\install-native-host.ps1 to register it.`,
      false
    );
  }
});

load();
