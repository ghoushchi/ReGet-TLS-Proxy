/*
 * ReGet Deluxe browser integration - background service worker / event page.
 *
 * Replaces the original Firefox 1.0-15.0 XPCOM overlay extension. That one shipped
 * a binary component (MozillaFFExtension.dll) which called CoCreateInstance on the
 * "ReGetDx.RegetDownloadApi" COM object directly from the browser process. Neither
 * binary components nor COM are reachable from a MV3 extension, so the COM call now
 * lives in a native messaging host and we talk to it over stdio.
 *
 * Feature parity with the original overlay:
 *   - download a right-clicked link
 *   - download every link on the page
 *   - download links inside the current selection
 * Plus media (image/video/audio) targets, which the original lacked.
 */

const api = globalThis.browser ?? globalThis.chrome;

const HOST_NAME = "com.reget.deluxe";

const DEFAULTS = {
  confirm: true,          // show ReGet's "Add download" confirmation dialog
  sendCookies: true,      // forward cookies so session-protected files work
  sendReferrer: true,
  takeOverDownloads: false, // intercept browser-initiated downloads
};

// Mirrors checkLink() from the original regetOverlay.js.
const SCHEME_OK = /^[a-z][a-z0-9+.-]*:\/\//i;
const SCHEME_BAD = /^(javascript|mailto|news|file|data|blob|about|chrome|moz-extension|chrome-extension):/i;

function usableUrl(url) {
  return typeof url === "string" && SCHEME_OK.test(url) && !SCHEME_BAD.test(url);
}

async function getSettings() {
  const stored = await api.storage.local.get(DEFAULTS);
  return { ...DEFAULTS, ...stored };
}

async function cookieHeaderFor(url) {
  try {
    const cookies = await api.cookies.getAll({ url });
    return cookies.map((c) => `${c.name}=${c.value}`).join("; ");
  } catch (err) {
    // No "cookies" permission for this URL, or a privileged scheme. Not fatal.
    console.warn("ReGet: could not read cookies for", url, err);
    return "";
  }
}

function notify(title, message) {
  try {
    api.notifications?.create({
      type: "basic",
      iconUrl: api.runtime.getURL("icons/reget-128.png"),
      title,
      message,
    });
  } catch {
    /* notifications are best-effort */
  }
}

/** Hand a batch of links to ReGetDx via the native host. */
async function sendToReGet(rawItems, tab) {
  const cfg = await getSettings();

  const items = [];
  for (const item of rawItems) {
    if (!usableUrl(item.url)) continue;
    items.push({
      url: item.url,
      info: item.info || "",
      referrer: cfg.sendReferrer ? item.referrer || tab?.url || "" : "",
      cookie: cfg.sendCookies ? await cookieHeaderFor(item.url) : "",
    });
  }

  if (items.length === 0) {
    notify("ReGet", "No downloadable links found.");
    return;
  }

  try {
    const reply = await api.runtime.sendNativeMessage(HOST_NAME, {
      action: "add",
      confirm: cfg.confirm,
      items,
    });

    if (reply?.ok) {
      const n = reply.added ?? items.length;
      const plural = n === 1 ? "" : "s";
      if (reply.confirmed) {
        notify("ReGet", `Added ${n} download${plural} to ReGet Deluxe.`);
      } else {
        // CLI fallback: the host launched ReGetDx but cannot tell whether the
        // download was queued. Say so rather than claiming success.
        notify(
          "ReGet (unconfirmed)",
          `Passed ${n} URL${plural} to ReGetDx via the command line. ` +
            `If nothing appears, run ReGetDx.exe /REGSERVER to enable the COM handoff.`
        );
      }
    } else {
      notify("ReGet failed", reply?.error || "The native host returned no result.");
    }
  } catch (err) {
    // Almost always: host not installed, or this extension ID is not in the
    // host manifest's allowed_origins / allowed_extensions list.
    notify(
      "ReGet host unreachable",
      `${err?.message || err}\n\nRun tools\\install-native-host.ps1 to register it.`
    );
    console.error("ReGet native messaging failed:", err);
  }
}

/* ------------------------------------------------------------------ */
/* Page-side collectors. Injected via scripting.executeScript.          */
/* ------------------------------------------------------------------ */

function collectAllLinks() {
  return Array.from(document.links)
    .map((a) => ({
      url: a.href,
      info: (a.title || a.textContent || "").replace(/\s+/g, " ").trim(),
      referrer: document.URL,
    }))
    .filter((l) => l.url);
}

function collectSelectedLinks() {
  const sel = window.getSelection();
  if (!sel || sel.isCollapsed || sel.rangeCount === 0) return [];
  const range = sel.getRangeAt(0);
  return Array.from(document.links)
    .filter((a) => range.intersectsNode(a))
    .map((a) => ({
      url: a.href,
      info: (a.title || a.textContent || "").replace(/\s+/g, " ").trim(),
      referrer: document.URL,
    }))
    .filter((l) => l.url);
}

async function runCollector(tab, fn) {
  const results = await api.scripting.executeScript({
    target: { tabId: tab.id, allFrames: false },
    func: fn,
  });
  return results?.[0]?.result ?? [];
}

/* ------------------------------------------------------------------ */
/* Context menus                                                        */
/* ------------------------------------------------------------------ */

const MENUS = [
  { id: "reget-link", title: "Download with ReGet", contexts: ["link"] },
  { id: "reget-media", title: "Download with ReGet", contexts: ["image", "video", "audio"] },
  { id: "reget-selection", title: "Download selected links with ReGet", contexts: ["selection"] },
  { id: "reget-all", title: "Download all links with ReGet", contexts: ["page"] },
];

function buildMenus() {
  api.contextMenus.removeAll(() => {
    for (const m of MENUS) api.contextMenus.create(m);
  });
}

api.runtime.onInstalled.addListener(buildMenus);
api.runtime.onStartup?.addListener(buildMenus);

api.contextMenus.onClicked.addListener(async (info, tab) => {
  try {
    switch (info.menuItemId) {
      case "reget-link":
        await sendToReGet(
          [{ url: info.linkUrl, info: info.linkText || "", referrer: info.pageUrl }],
          tab
        );
        break;

      case "reget-media":
        await sendToReGet([{ url: info.srcUrl, info: "", referrer: info.pageUrl }], tab);
        break;

      case "reget-selection":
        await sendToReGet(await runCollector(tab, collectSelectedLinks), tab);
        break;

      case "reget-all":
        await sendToReGet(await runCollector(tab, collectAllLinks), tab);
        break;
    }
  } catch (err) {
    console.error("ReGet context menu handler failed:", err);
    notify("ReGet", String(err?.message || err));
  }
});

/* ------------------------------------------------------------------ */
/* Optional: take over downloads the browser starts                     */
/* ------------------------------------------------------------------ */

api.downloads?.onCreated.addListener(async (item) => {
  const cfg = await getSettings();
  if (!cfg.takeOverDownloads) return;
  if (!usableUrl(item.url)) return;

  try {
    await api.downloads.cancel(item.id);
    await api.downloads.erase({ id: item.id });
  } catch (err) {
    console.warn("ReGet: could not cancel browser download", err);
    return; // let the browser keep it rather than losing the download entirely
  }
  await sendToReGet([{ url: item.url, info: item.filename || "", referrer: item.referrer || "" }], null);
});

/* Toolbar click -> options page */
api.action?.onClicked.addListener(() => api.runtime.openOptionsPage());
